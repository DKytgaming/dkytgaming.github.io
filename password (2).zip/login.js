function validate()
{
  var username=document.getElementById("username").value;
  var password=document.getElementById("password").value;
  if(username=="admin"&& password=="user")
{
    <a href="test.html"></a>
    return false;
}
else
{
    alert("login failed");
}
}